#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/ledc.h"

// Definição dos pinos GPIO
#define LED_R_PIN 25 // Pino para o LED Vermelho
#define LED_G_PIN 26 // Pino para o LED Verde
#define LED_B_PIN 27 // Pino para o LED Azul

// Parâmetros PWM
#define PWM_FREQUENCY 5000  // Frequência do PWM em Hz
#define PWM_RESOLUTION LEDC_TIMER_8_BIT  // Resolução de 8 bits (0-255)
#define PWM_INCREMENT 5  // Valor de incremento do duty cycle

// Definição dos canais PWM
#define LEDC_TIMER LEDC_TIMER_0
#define LEDC_MODE LEDC_LOW_SPEED_MODE
#define CHANNEL_R LEDC_CHANNEL_0
#define CHANNEL_G LEDC_CHANNEL_1
#define CHANNEL_B LEDC_CHANNEL_2

// Configuração inicial do LEDC
void configure_ledc()
{
    // Configuração do timer
    ledc_timer_config_t ledc_timer = {
        .speed_mode = LEDC_MODE,
        .timer_num = LEDC_TIMER,
        .duty_resolution = PWM_RESOLUTION,
        .freq_hz = PWM_FREQUENCY,
        .clk_cfg = LEDC_AUTO_CLK,
    };
    ledc_timer_config(&ledc_timer);

    // Configuração dos canais PWM para R, G e B
    ledc_channel_config_t ledc_channel[3] = {
        {
            .speed_mode = LEDC_MODE,
            .channel = CHANNEL_R,
            .timer_sel = LEDC_TIMER,
            .intr_type = LEDC_INTR_DISABLE,
            .gpio_num = LED_R_PIN,
            .duty = 0,
            .hpoint = 0,
        },
        {
            .speed_mode = LEDC_MODE,
            .channel = CHANNEL_G,
            .timer_sel = LEDC_TIMER,
            .intr_type = LEDC_INTR_DISABLE,
            .gpio_num = LED_G_PIN,
            .duty = 0,
            .hpoint = 0,
        },
        {
            .speed_mode = LEDC_MODE,
            .channel = CHANNEL_B,
            .timer_sel = LEDC_TIMER,
            .intr_type = LEDC_INTR_DISABLE,
            .gpio_num = LED_B_PIN,
            .duty = 0,
            .hpoint = 0,
        }
    };

    // Configuração dos canais no LEDC
    for (int i = 0; i < 3; i++) {
        ledc_channel_config(&ledc_channel[i]);
    }
}

// Função principal de controle PWM
void led_pwm_control(void *pvParameters)
{
    uint8_t duty_r = 0;
    uint8_t duty_g = 0;
    uint8_t duty_b = 0;

    while (1) {
        // Atualiza os duty cycles de cada cor com os incrementos
        duty_r = (duty_r + PWM_INCREMENT * 2) % 256;
        duty_g = (duty_g + PWM_INCREMENT) % 256;
        duty_b = (duty_b + PWM_INCREMENT * 3) % 256;

        // Define os valores de duty cycle nos canais PWM
        ledc_set_duty(LEDC_MODE, CHANNEL_R, duty_r);
        ledc_update_duty(LEDC_MODE, CHANNEL_R);

        ledc_set_duty(LEDC_MODE, CHANNEL_G, duty_g);
        ledc_update_duty(LEDC_MODE, CHANNEL_G);

        ledc_set_duty(LEDC_MODE, CHANNEL_B, duty_b);
        ledc_update_duty(LEDC_MODE, CHANNEL_B);

        // Exibe informações no Monitor Serial
        printf("Incremento: %d | Duty R: %d | Duty G: %d | Duty B: %d\n",
               PWM_INCREMENT, duty_r, duty_g, duty_b);

        // Aguarda 100ms antes de atualizar os valores
        vTaskDelay(pdMS_TO_TICKS(100));
    }
}

void app_main()
{
    // Configura os pinos PWM do LED RGB
    configure_ledc();

    // Cria a tarefa de controle PWM
    xTaskCreate(led_pwm_control, "LED PWM Control", 2048, NULL, 5, NULL);
}
